#include <windows.h>
#include <iostream>
#include <vector>
#include <string>
#include <map>
#include <thread>
#include <mutex>
#include <atomic>
#include <chrono>
#include <fstream>
#include <sstream>

class RegistryLockService {
private:
    struct RegistryKeyInfo {
        HKEY hKey;
        std::string subKey;
        std::string valueName;
        DWORD valueType;
        std::vector<BYTE> originalData;
        bool exists;
    };

    std::vector<std::string> monitoredPaths;
    std::map<std::string, RegistryKeyInfo> registryBackup;
    std::mutex backupMutex;
    std::atomic<bool> isRunning;
    std::thread monitorThread;
    
    // 配置参数
    int scanIntervalMs = 100;  // 扫描间隔毫秒
    bool verbose = false;

public:
    RegistryLockService() : isRunning(false) {}

    void addMonitorPath(const std::string& path) {
        monitoredPaths.push_back(path);
    }

    void setScanInterval(int intervalMs) {
        scanIntervalMs = intervalMs;
    }

    void setVerbose(bool v) {
        verbose = v;
    }

    bool start() {
        if (isRunning.load()) {
            std::cout << "服务已经在运行中" << std::endl;
            return false;
        }

        if (monitoredPaths.empty()) {
            std::cout << "错误：没有指定监控路径" << std::endl;
            return false;
        }

        std::cout << "开始注册表锁定服务..." << std::endl;
        std::cout << "监控路径数量: " << monitoredPaths.size() << std::endl;
        
        // 备份所有注册表值
        if (!backupRegistryValues()) {
            std::cout << "备份注册表值失败" << std::endl;
            return false;
        }

        isRunning.store(true);
        monitorThread = std::thread(&RegistryLockService::monitorLoop, this);
        
        std::cout << "注册表锁定服务已启动" << std::endl;
        return true;
    }

    void stop() {
        if (!isRunning.load()) {
            return;
        }

        std::cout << "停止注册表锁定服务..." << std::endl;
        isRunning.store(false);
        
        if (monitorThread.joinable()) {
            monitorThread.join();
        }
        
        std::cout << "注册表锁定服务已停止" << std::endl;
    }

    ~RegistryLockService() {
        stop();
    }

private:
    bool backupRegistryValues() {
        std::lock_guard<std::mutex> lock(backupMutex);
        
        for (const auto& path : monitoredPaths) {
            if (!backupPathValues(path)) {
                std::cout << "备份路径失败: " << path << std::endl;
                return false;
            }
        }
        
        if (verbose) {
            std::cout << "成功备份 " << registryBackup.size() << " 个注册表值" << std::endl;
        }
        return true;
    }

    bool backupPathValues(const std::string& path) {
        std::vector<std::string> pathParts = splitPath(path);
        if (pathParts.size() < 2) {
            return false;
        }

        HKEY hKey = getRootKey(pathParts[0]);
        if (hKey == nullptr) {
            return false;
        }

        std::string subKey = joinPath(pathParts, 1);
        HKEY hSubKey;
        
        if (RegOpenKeyExA(hKey, subKey.c_str(), 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) {
            return false;
        }

        // 获取所有值名称
        char valueName[MAX_PATH];
        DWORD valueNameSize;
        DWORD index = 0;

        while (true) {
            valueNameSize = MAX_PATH;
            DWORD valueType;
            DWORD dataSize = 0;
            
            // 先获取数据大小
            LONG result = RegEnumValueA(hSubKey, index, valueName, &valueNameSize, 
                                      nullptr, &valueType, nullptr, &dataSize);
            
            if (result == ERROR_NO_MORE_ITEMS) {
                break;
            }
            
            if (result == ERROR_SUCCESS && valueNameSize > 0) {
                // 读取数据
                std::vector<BYTE> data(dataSize);
                result = RegEnumValueA(hSubKey, index, valueName, &valueNameSize, 
                                     nullptr, &valueType, data.data(), &dataSize);
                
                if (result == ERROR_SUCCESS) {
                    RegistryKeyInfo keyInfo;
                    keyInfo.hKey = hKey;
                    keyInfo.subKey = subKey;
                    keyInfo.valueName = valueName;
                    keyInfo.valueType = valueType;
                    keyInfo.originalData = data;
                    keyInfo.exists = true;
                    
                    std::string fullKey = path + "\\" + valueName;
                    registryBackup[fullKey] = keyInfo;
                    
                    if (verbose) {
                        std::cout << "备份: " << fullKey << " (类型: " << valueType << ")" << std::endl;
                    }
                }
            }
            
            index++;
        }

        RegCloseKey(hSubKey);
        return true;
    }

    void monitorLoop() {
        std::cout << "开始监控注册表变更..." << std::endl;
        
        while (isRunning.load()) {
            std::vector<std::string> changes = detectChanges();
            
            for (const auto& change : changes) {
                if (verbose) {
                    std::cout << "检测到变更: " << change << std::endl;
                }
                
                restoreValue(change);
            }
            
            std::this_thread::sleep_for(std::chrono::milliseconds(scanIntervalMs));
        }
    }

    std::vector<std::string> detectChanges() {
        std::vector<std::string> changes;
        std::lock_guard<std::mutex> lock(backupMutex);
        
        for (auto& [keyPath, originalInfo] : registryBackup) {
            bool currentExists = false;
            RegistryKeyInfo currentInfo;
            
            if (getCurrentValueInfo(keyPath, currentInfo)) {
                currentExists = true;
                
                // 检查值类型或数据是否变化
                if (currentInfo.valueType != originalInfo.valueType || 
                    currentInfo.originalData != originalInfo.originalData) {
                    changes.push_back(keyPath);
                }
            } else {
                // 值不存在，需要恢复
                if (originalInfo.exists) {
                    changes.push_back(keyPath);
                }
            }
        }
        
        return changes;
    }

    bool getCurrentValueInfo(const std::string& keyPath, RegistryKeyInfo& info) {
        std::vector<std::string> pathParts = splitPath(keyPath);
        if (pathParts.size() < 3) {
            return false;
        }

        HKEY hKey = getRootKey(pathParts[0]);
        if (hKey == nullptr) {
            return false;
        }

        std::string subKey = joinPath(pathParts, 1, pathParts.size() - 2);
        std::string valueName = pathParts.back();
        
        HKEY hSubKey;
        if (RegOpenKeyExA(hKey, subKey.c_str(), 0, KEY_READ, &hSubKey) != ERROR_SUCCESS) {
            return false;
        }

        DWORD dataSize = 0;
        LONG result = RegQueryValueExA(hSubKey, valueName.c_str(), nullptr, 
                                     &info.valueType, nullptr, &dataSize);
        
        if (result == ERROR_SUCCESS && dataSize > 0) {
            info.originalData.resize(dataSize);
            result = RegQueryValueExA(hSubKey, valueName.c_str(), nullptr, 
                                    &info.valueType, info.originalData.data(), &dataSize);
            
            RegCloseKey(hSubKey);
            return (result == ERROR_SUCCESS);
        }

        RegCloseKey(hSubKey);
        return false;
    }

    void restoreValue(const std::string& keyPath) {
        std::lock_guard<std::mutex> lock(backupMutex);
        
        auto it = registryBackup.find(keyPath);
        if (it == registryBackup.end()) {
            return;
        }

        const RegistryKeyInfo& originalInfo = it->second;
        HKEY hKey = originalInfo.hKey;
        std::string subKey = originalInfo.subKey;
        std::string valueName = originalInfo.valueName;

        HKEY hSubKey;
        DWORD disposition;
        
        LONG result = RegCreateKeyExA(hKey, subKey.c_str(), 0, nullptr, 
                                    REG_OPTION_NON_VOLATILE, KEY_SET_VALUE, 
                                    nullptr, &hSubKey, &disposition);
        
        if (result == ERROR_SUCCESS) {
            result = RegSetValueExA(hSubKey, valueName.c_str(), 0, originalInfo.valueType,
                                   originalInfo.originalData.data(), 
                                   static_cast<DWORD>(originalInfo.originalData.size()));
            
            if (result == ERROR_SUCCESS) {
                std::cout << "[恢复] " << keyPath << " -> 已恢复原始值" << std::endl;
            } else {
                std::cout << "[错误] 无法设置值 " << keyPath << ", 错误码: " << result << std::endl;
            }
            
            RegCloseKey(hSubKey);
        } else {
            std::cout << "[错误] 无法创建键 " << subKey << ", 错误码: " << result << std::endl;
        }
    }

    HKEY getRootKey(const std::string& rootKeyName) {
        if (_stricmp(rootKeyName.c_str(), "HKEY_CLASSES_ROOT") == 0 || 
            _stricmp(rootKeyName.c_str(), "HKCR") == 0) {
            return HKEY_CLASSES_ROOT;
        } else if (_stricmp(rootKeyName.c_str(), "HKEY_CURRENT_USER") == 0 || 
                   _stricmp(rootKeyName.c_str(), "HKCU") == 0) {
            return HKEY_CURRENT_USER;
        } else if (_stricmp(rootKeyName.c_str(), "HKEY_LOCAL_MACHINE") == 0 || 
                   _stricmp(rootKeyName.c_str(), "HKLM") == 0) {
            return HKEY_LOCAL_MACHINE;
        } else if (_stricmp(rootKeyName.c_str(), "HKEY_USERS") == 0 || 
                   _stricmp(rootKeyName.c_str(), "HKU") == 0) {
            return HKEY_USERS;
        } else if (_stricmp(rootKeyName.c_str(), "HKEY_CURRENT_CONFIG") == 0 || 
                   _stricmp(rootKeyName.c_str(), "HKCC") == 0) {
            return HKEY_CURRENT_CONFIG;
        }
        return nullptr;
    }

    std::vector<std::string> splitPath(const std::string& path) {
        std::vector<std::string> parts;
        std::stringstream ss(path);
        std::string part;
        
        while (std::getline(ss, part, '\\')) {
            if (!part.empty()) {
                parts.push_back(part);
            }
        }
        
        return parts;
    }

    std::string joinPath(const std::vector<std::string>& parts, size_t start, size_t end = std::string::npos) {
        std::string result;
        size_t count = (end == std::string::npos) ? parts.size() - start : end - start;
        
        for (size_t i = 0; i < count; i++) {
            if (i > 0) {
                result += "\\";
            }
            result += parts[start + i];
        }
        
        return result;
    }
};

// 全局服务实例
std::unique_ptr<RegistryLockService> g_service;
std::atomic<bool> g_shutdownRequested(false);

// 信号处理函数
BOOL WINAPI ConsoleCtrlHandler(DWORD ctrlType) {
    switch (ctrlType) {
        case CTRL_C_EVENT:
        case CTRL_BREAK_EVENT:
        case CTRL_CLOSE_EVENT:
        case CTRL_LOGOFF_EVENT:
        case CTRL_SHUTDOWN_EVENT:
            std::cout << "\n收到关闭信号，正在停止服务..." << std::endl;
            g_shutdownRequested.store(true);
            if (g_service) {
                g_service->stop();
            }
            return TRUE;
        default:
            return FALSE;
    }
}

void printUsage() {
    std::cout << "用法: RegistryLockService.exe [选项] <注册表路径1> [注册表路径2] ..." << std::endl;
    std::cout << std::endl;
    std::cout << "选项:" << std::endl;
    std::cout << "  -interval <毫秒>    设置扫描间隔 (默认: 100ms)" << std::endl;
    std::cout << "  -verbose           启用详细输出" << std::endl;
    std::cout << "  -help              显示此帮助信息" << std::endl;
    std::cout << std::endl;
    std::cout << "示例:" << std::endl;
    std::cout << "  RegistryLockService.exe HKEY_CURRENT_USER\\Software\\MyApp" << std::endl;
    std::cout << "  RegistryLockService.exe -interval 50 -verbose HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft" << std::endl;
    std::cout << std::endl;
    std::cout << "支持的根键:" << std::endl;
    std::cout << "  HKEY_CLASSES_ROOT (HKCR)" << std::endl;
    std::cout << "  HKEY_CURRENT_USER (HKCU)" << std::endl;
    std::cout << "  HKEY_LOCAL_MACHINE (HKLM)" << std::endl;
    std::cout << "  HKEY_USERS (HKU)" << std::endl;
    std::cout << "  HKEY_CURRENT_CONFIG (HKCC)" << std::endl;
}

int main(int argc, char* argv[]) {
    std::cout << "=== 注册表动态锁定服务 ===" << std::endl;
    std::cout << "版本: 1.0" << std::endl;
    std::cout << std::endl;

    if (argc < 2) {
        printUsage();
        return 1;
    }

    // 解析命令行参数
    g_service = std::make_unique<RegistryLockService>();
    std::vector<std::string> paths;
    
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        
        if (arg == "-help" || arg == "--help" || arg == "/help") {
            printUsage();
            return 0;
        } else if (arg == "-interval") {
            if (i + 1 < argc) {
                int interval = std::stoi(argv[++i]);
                if (interval > 0 && interval < 60000) {
                    g_service->setScanInterval(interval);
                } else {
                    std::cout << "错误：扫描间隔必须在 1-60000 毫秒之间" << std::endl;
                    return 1;
                }
            } else {
                std::cout << "错误：-interval 需要一个参数" << std::endl;
                return 1;
            }
        } else if (arg == "-verbose" || arg == "-v") {
            g_service->setVerbose(true);
        } else if (arg[0] == '-') {
            std::cout << "未知选项: " << arg << std::endl;
            printUsage();
            return 1;
        } else {
            paths.push_back(arg);
        }
    }

    if (paths.empty()) {
        std::cout << "错误：至少需要指定一个注册表路径" << std::endl;
        return 1;
    }

    // 验证和添加监控路径
    for (const auto& path : paths) {
        std::cout << "添加监控路径: " << path << std::endl;
        g_service->addMonitorPath(path);
    }

    // 设置控制台信号处理
    SetConsoleCtrlHandler(ConsoleCtrlHandler, TRUE);

    // 启动服务
    if (!g_service->start()) {
        std::cout << "服务启动失败" << std::endl;
        return 1;
    }

    std::cout << std::endl;
    std::cout << "服务运行中..." << std::endl;
    std::cout << "按 Ctrl+C 停止服务" << std::endl;
    std::cout << std::endl;

    // 主循环
    while (!g_shutdownRequested.load()) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    std::cout << "服务已关闭" << std::endl;
    return 0;
}