@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ========================================
echo 注册表锁定服务 - 安装和部署脚本
echo ========================================
echo.

REM 检查管理员权限
net session >nul 2>&1
if %errorLevel% == 0 (
    echo [✓] 检测到管理员权限
) else (
    echo [✗] 错误：需要管理员权限运行此脚本
    echo 请右键点击脚本，选择"以管理员身份运行"
    pause
    exit /b 1
)

echo.
echo 1. 检查程序文件...
if not exist "RegistryLockService.exe" (
    echo [✗] RegistryLockService.exe 不存在
    echo 请先运行构建命令：cmake --build . --config Release
    pause
    exit /b 1
)
echo [✓] RegistryLockService.exe 存在

echo.
echo 2. 创建安装目录...
set "install_dir=C:\RegistryLockService"
if exist "%install_dir%" (
    echo 目录已存在，将覆盖安装...
) else (
    mkdir "%install_dir%"
)
echo [✓] 安装目录: %install_dir%

echo.
echo 3. 复制程序文件...
copy "RegistryLockService.exe" "%install_dir%\RegistryLockService.exe" >nul
if %errorlevel% equ 0 (
    echo [✓] 程序文件复制完成
) else (
    echo [✗] 程序文件复制失败
    pause
    exit /b 1
)

echo.
echo 4. 创建配置文件...
(
echo # 注册表锁定服务配置文件
echo # 每行一个注册表路径
echo # 注释行以 # 开头
echo.
echo # 示例配置
echo HKEY_CURRENT_USER\Software
echo # HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft
) > "%install_dir%\config.txt"

echo [✓] 配置文件创建完成: %install_dir%\config.txt

echo.
echo 5. 创建Windows服务...
echo 创建Windows服务可能需要一些权限...

REM 尝试使用sc命令创建服务
sc create "RegistryLockService" binPath= "\"%install_dir%\RegistryLockService.exe\" -config \"%install_dir%\config.txt\"" type= own start= demand DisplayName= "Registry Lock Service" >nul 2>&1

if %errorlevel% equ 0 (
    echo [✓] Windows服务创建成功
) else (
    echo [!] Windows服务创建失败（这可能是正常的）
    echo 您仍然可以手动运行程序
)

echo.
echo 6. 创建快捷方式...
REM 创建桌面快捷方式
powershell -Command "$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%USERPROFILE%\Desktop\注册表锁定服务.lnk'); $Shortcut.TargetPath = '%install_dir%\RegistryLockService.exe'; $Shortcut.WorkingDirectory = '%install_dir%'; $Shortcut.Description = '注册表锁定服务 - 保护重要注册表设置'; $Shortcut.Save()" >nul 2>&1

echo [✓] 桌面快捷方式创建完成

echo.
echo 7. 创建卸载脚本...
(
echo @echo off
echo echo 正在卸载注册表锁定服务...
echo.
echo REM 停止并删除Windows服务
echo sc stop "RegistryLockService" ^>nul 2^>^&1
echo sc delete "RegistryLockService" ^>nul 2^>^&1
echo.
echo REM 删除安装目录
echo if exist "%install_dir%" ^(
echo     rmdir /s /q "%install_dir%"
echo     echo 安装目录已删除
echo ^) else ^(
echo     echo 安装目录不存在
echo ^)
echo.
echo REM 删除桌面快捷方式
echo del /f /q "%%USERPROFILE%%\Desktop\注册表锁定服务.lnk" ^>nul 2^>^&1
echo.
echo echo 卸载完成！
echo pause
) > "%install_dir%\uninstall.bat"

echo [✓] 卸载脚本创建完成: %install_dir%\uninstall.bat

echo.
echo ========================================
echo 安装完成！
echo ========================================
echo.
echo 安装位置: %install_dir%
echo 配置文件: %install_dir%\config.txt
echo 卸载程序: %install_dir%\uninstall.bat
echo 桌面快捷方式: 注册表锁定服务.lnk
echo.
echo 使用说明：
echo 1. 双击桌面快捷方式或直接运行 RegistryLockService.exe
echo 2. 编辑 config.txt 添加要监控的注册表路径
echo 3. 如果创建了Windows服务，可以使用 services.msc 管理
echo.
echo 按任意键打开安装目录...
pause >nul
explorer "%install_dir%"