@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ========================================
echo 注册表锁定服务 - 常用路径监控
echo ========================================
echo.

REM 检查RegistryLockService.exe是否存在
if not exist "RegistryLockService.exe" (
    echo 错误：RegistryLockService.exe不存在
    echo 请先构建程序：cmake --build . --config Release
    pause
    exit /b 1
)

:menu
cls
echo ========================================
echo 请选择要监控的注册表路径：
echo ========================================
echo.
echo 1. 当前用户软件设置 (HKEY_CURRENT_USER\Software)
echo 2. 本地机器软件设置 (HKEY_LOCAL_MACHINE\SOFTWARE)
echo 3. Windows安全策略 (HKEY_LOCAL_MACHINE\SOFTWARE\Policies)
echo 4. Microsoft系统设置 (HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft)
echo 5. 自定义路径
echo 6. 退出
echo.
set /p choice="请输入选项 (1-6): "

if "%choice%"=="1" goto monitor_hkcu
if "%choice%"=="2" goto monitor_hklm_software
if "%choice%"=="3" goto monitor_policies
if "%choice%"=="4" goto monitor_microsoft
if "%choice%"=="5" goto custom_path
if "%choice%"=="6" goto exit
goto menu

:monitor_hkcu
set "monitor_path=HKEY_CURRENT_USER\Software"
set "description=当前用户软件设置"
goto start_monitoring

:monitor_hklm_software
set "monitor_path=HKEY_LOCAL_MACHINE\SOFTWARE"
set "description=本地机器软件设置"
goto start_monitoring

:monitor_policies
set "monitor_path=HKEY_LOCAL_MACHINE\SOFTWARE\Policies"
set "description=Windows安全策略"
goto start_monitoring

:monitor_microsoft
set "monitor_path=HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft"
set "description=Microsoft系统设置"
goto start_monitoring

:custom_path
echo.
set /p monitor_path="请输入要监控的注册表路径: "
if "!monitor_path!"=="" (
    echo 错误：路径不能为空
    pause
    goto menu
)
set "description=自定义路径"
goto start_monitoring

:start_monitoring
cls
echo ========================================
echo 监控配置
echo ========================================
echo.
echo 监控路径: !monitor_path!
echo 描述: !description!
echo.

REM 询问是否使用管理员权限
echo 警告：某些路径可能需要管理员权限
set /p admin="是否以管理员权限运行？(Y/N): "
if /i "!admin!"=="Y" (
    set "run_as_admin=runas"
) else (
    set "run_as_admin="
)

echo.
echo 可选参数：
echo 1. 默认设置 (扫描间隔: 100ms)
echo 2. 高性能模式 (扫描间隔: 50ms)
echo 3. 节能模式 (扫描间隔: 500ms)
echo 4. 详细模式
echo 5. 完整配置
echo.
set /p config="请选择配置 (1-5): "

set "args="
if "%config%"=="2" set "args=-interval 50"
if "%config%"=="3" set "args=-interval 500"
if "%config%"=="4" set "args=-verbose"
if "%config%"=="5" set "args=-interval 50 -verbose"

echo.
echo ========================================
echo 启动监控
echo ========================================
echo.
echo 监控路径: !monitor_path!
echo 命令行: RegistryLockService.exe !args! "!monitor_path!"
echo.

if "%run_as_admin%"=="runas" (
    echo 正在以管理员权限启动...
    echo 可能会提示输入管理员密码...
    echo.
    start "RegistryLockService - Admin" cmd /k "RegistryLockService.exe !args! "!monitor_path!""
) else (
    echo 正在启动服务...
    start "RegistryLockService" cmd /k "RegistryLockService.exe !args! "!monitor_path!""
)

echo.
echo 服务已在新窗口中启动
echo.
echo 使用说明：
echo - 观察服务窗口中的实时日志
echo - 如果检测到变更，会显示 "[恢复]" 信息
echo - 按 Ctrl+C 可停止服务
echo.
echo 按任意键返回主菜单...
pause >nul
goto menu

:exit
echo 谢谢使用！
pause
exit /b 0