@echo off
echo ========================================
echo 注册表锁定服务测试脚本
echo ========================================
echo.

REM 检查RegistryLockService.exe是否存在
if not exist "RegistryLockService.exe" (
    echo 错误：RegistryLockService.exe不存在
    echo 请先构建程序：cmake --build . --config Release
    pause
    exit /b 1
)

echo 正在构建注册表测试环境...
echo.

REM 创建测试注册表路径
echo 创建测试注册表项...
reg add "HKEY_CURRENT_USER\Software\RegistryLockTest" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\RegistryLockTest\Settings" /f >nul 2>&1

REM 添加测试数据
echo 添加测试数据...
reg add "HKEY_CURRENT_USER\Software\RegistryLockTest\Settings" /v "TestString" /t REG_SZ /d "OriginalValue" /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\RegistryLockTest\Settings" /v "TestNumber" /t REG_DWORD /d 12345 /f >nul 2>&1
reg add "HKEY_CURRENT_USER\Software\RegistryLockTest\Settings" /v "TestBinary" /t REG_BINARY /d "414243" /f >nul 2>&1

echo.
echo 当前注册表值：
reg query "HKEY_CURRENT_USER\Software\RegistryLockTest\Settings"

echo.
echo ========================================
echo 启动注册表锁定服务
echo ========================================
echo 服务将监控: HKEY_CURRENT_USER\Software\RegistryLockTest\Settings
echo 请在新窗口中修改注册表来测试功能
echo.
echo 按任意键启动服务...
pause >nul

start "RegistryLockService" cmd /k "RegistryLockService.exe -verbose -interval 100 HKEY_CURRENT_USER\Software\RegistryLockTest\Settings"

echo.
echo 服务已启动在新窗口中
echo 在新窗口中，您可以：
echo 1. 观察服务监控状态
echo 2. 使用reg命令修改注册表进行测试
echo.
echo 测试完成后，请在新窗口中按Ctrl+C停止服务
echo 然后按任意键清理测试环境...
pause >nul

echo.
echo 清理测试环境...
reg delete "HKEY_CURRENT_USER\Software\RegistryLockTest" /f >nul 2>&1
echo 测试完成！
pause