@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

echo ========================================
echo 注册表锁定服务性能测试
echo ========================================
echo.

REM 检查RegistryLockService.exe是否存在
if not exist "RegistryLockService.exe" (
    echo 错误：RegistryLockService.exe不存在
    echo 请先构建程序：cmake --build . --config Release
    pause
    exit /b 1
)

echo 创建测试环境...
echo.

REM 创建大型测试注册表结构
echo 创建大型注册表测试结构...
set "test_path=HKEY_CURRENT_USER\Software\RegistryLockTest\LargeTest"

for /l %%i in (1,1,50) do (
    for /l %%j in (1,1,20) do (
        set "key_name=Key%%i_SubKey%%j"
        reg add "%test_path%\%%key_name%" /f >nul 2>&1
        
        REM 为每个键添加多个值
        for /l %%k in (1,1,5) do (
            set "value_name=Value%%k"
            if %%k equ 1 (
                reg add "%test_path%\%%key_name%" /v "!value_name!" /t REG_SZ /d "TestStringData_%%i_%%j_%%k" /f >nul 2>&1
            ) else if %%k equ 2 (
                reg add "%test_path%\%%key_name%" /v "!value_name!" /t REG_DWORD /d 12345678 /f >nul 2>&1
            ) else if %%k equ 3 (
                reg add "%test_path%\%%key_name%" /v "!value_name!" /t REG_BINARY /d "414243444546" /f >nul 2>&1
            ) else if %%k equ 4 (
                reg add "%test_path%\%%key_name%" /v "!value_name!" /t REG_EXPAND_SZ /d "%%TEMP%%\testpath" /f >nul 2>&1
            ) else (
                reg add "%test_path%\%%key_name%" /v "!value_name!" /t REG_MULTI_SZ /d "Line1\0Line2\0Line3" /f >nul 2>&1
            )
        )
    )
)

echo 测试注册表结构创建完成
echo.

echo ========================================
echo 性能测试菜单
echo ========================================
echo.
echo 1. 低频监控测试 (500ms间隔)
echo 2. 标准监控测试 (100ms间隔)
echo 3. 高频监控测试 (50ms间隔)
echo 4. 超高频监控测试 (10ms间隔)
echo 5. 自定义间隔测试
echo 6. 清理测试数据并退出
echo.
set /p test_choice="请选择测试类型 (1-6): "

if "%test_choice%"=="1" goto test_low_freq
if "%test_choice%"=="2" goto test_standard
if "%test_choice%"=="3" goto test_high_freq
if "%test_choice%"=="4" goto test_ultra_freq
if "%test_choice%"=="5" goto test_custom
if "%test_choice%"=="6" goto cleanup
goto menu

:test_low_freq
set "interval=500"
set "description=低频监控测试"
goto start_performance_test

:test_standard
set "interval=100"
set "description=标准监控测试"
goto start_performance_test

:test_high_freq
set "interval=50"
set "description=高频监控测试"
goto start_performance_test

:test_ultra_freq
set "interval=10"
set "description=超高频监控测试"
goto start_performance_test

:test_custom
set /p interval="请输入扫描间隔(毫秒, 10-1000): "
if !interval! LSS 10 set "interval=10"
if !interval! GTR 1000 set "interval=1000"
set "description=自定义间隔测试"
goto start_performance_test

:start_performance_test
cls
echo ========================================
echo 性能测试: %description%
echo ========================================
echo.
echo 测试路径: %test_path%
echo 扫描间隔: %interval%ms
echo.
echo 开始前请注意：
echo 1. 监控系统会启动在新窗口
echo 2. 您可以在另一个窗口中修改注册表来测试恢复功能
echo 3. 按Ctrl+C停止监控
echo 4. 测试完成后请返回此窗口
echo.
echo 监控窗口将显示：
echo - 初始备份过程
echo - 实时监控统计
echo - 检测到的变更和恢复操作
echo.
echo 按任意键启动性能测试...
pause >nul

echo 启动性能测试...
start "RegistryLockService - Performance Test" cmd /k "RegistryLockService.exe -interval %interval% -verbose \"%test_path%\""

echo.
echo 性能测试已启动在新窗口中
echo.
echo 测试说明：
echo - 监控系统会显示扫描统计信息
echo - 可以用reg命令修改注册表测试恢复功能
echo - 观察CPU和内存使用情况
echo - 记录恢复操作的响应时间
echo.
echo 测试完成后，在监控窗口按Ctrl+C停止
echo 然后按任意键继续...
pause >nul

echo.
echo 性能测试完成
echo.
set /p continue="是否继续其他测试？(Y/N): "
if /i "!continue!"=="Y" goto menu
goto cleanup

:cleanup
echo.
echo 清理测试数据...
reg delete "HKEY_CURRENT_USER\Software\RegistryLockTest" /f >nul 2>&1
echo 测试数据已清理
echo.
echo 性能测试完成！
pause
exit /b 0

:menu
goto :eof