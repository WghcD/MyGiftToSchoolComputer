---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 304402203ba42e1c19d77d1fb9ce811d45bbb0438875d9a191191d29394fb59330d7739202205ea59f0d32cb9bf8f5443f4a031226cb55d889a68c702681d643ad85482ebade
    ReservedCode2: 3046022100e6a7dfacc4d7bf8feee6026a328af29224447a88c69199d2648ae1252d9ade5a022100f78cce99080471d84200045be3fd510b21e43d91d6fa315ff287c128798ef147
---

# 构建指南

## 系统要求

### 操作系统
- Windows 10 (版本 1809 或更高)
- Windows 11
- Windows Server 2016 或更高版本

### 开发环境
- Visual Studio 2019 或更高版本 (推荐)
- CMake 3.10 或更高版本
- 支持C++17的编译器

### 依赖项
本项目只依赖Windows系统库，无需额外安装第三方依赖。

## 构建方法

### 方法1：Visual Studio IDE (推荐)

#### 步骤1：打开项目
1. 打开Visual Studio
2. 选择"打开本地文件夹"
3. 选择包含`CMakeLists.txt`的文件夹
4. Visual Studio将自动配置CMake项目

#### 步骤2：选择配置
1. 在解决方案配置下拉菜单中选择`x64-Release`
2. 在解决方案平台中选择`x64`

#### 步骤3：构建
1. 按`Ctrl+Shift+B`或点击"生成"菜单
2. 或在解决方案资源管理器中右键点击项目选择"生成"

#### 步骤4：运行
1. 按`F5`运行程序
2. 或在解决方案资源管理器中右键点击可执行文件选择"调试"开始执行"

### 方法2：Visual Studio Developer Command Prompt

#### 步骤1：打开命令行
1. 打开"Developer Command Prompt for VS"
2. 导航到项目目录

#### 步骤2：创建构建目录
```cmd
mkdir build
cd build
```

#### 步骤3：配置CMake
```cmd
cmake .. -A x64
```

#### 步骤4：构建
```cmd
cmake --build . --config Release
```

#### 步骤5：运行
```cmd
bin\Release\RegistryLockService.exe -help
```

### 方法3：CMake + Ninja (推荐用于CI/CD)

#### 步骤1：安装Ninja
1. 从 https://github.com/ninja-build/ninja/releases 下载Ninja
2. 将ninja.exe添加到系统PATH

#### 步骤2：构建
```cmd
mkdir build
cd build
cmake .. -G Ninja -DCMAKE_BUILD_TYPE=Release
ninja
```

### 方法4：MinGW

#### 步骤1：安装MinGW
1. 下载并安装MinGW-w64
2. 确保gcc在系统PATH中

#### 步骤2：构建
```cmd
mkdir build
cd build
cmake .. -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release
mingw32-make
```

### 方法5：MSBuild命令行

#### 步骤1：生成Visual Studio解决方案
```cmd
cmake .. -A x64
```

#### 步骤2：构建
```cmd
MSBuild.exe ALL_BUILD.vcxproj /p:Configuration=Release /p:Platform=x64
```

## 构建配置

### Debug配置
```cmd
cmake .. -DCMAKE_BUILD_TYPE=Debug
```

### Release配置 (优化)
```cmd
cmake .. -DCMAKE_BUILD_TYPE=Release
```

### 自定义编译选项
```cmd
cmake .. -DCMAKE_CXX_FLAGS="-O2 -DNDEBUG" -DCMAKE_BUILD_TYPE=Release
```

## 常见问题解决

### 问题1：CMake版本过低
**错误信息**: `CMake 3.10 or higher is required`

**解决方案**:
1. 访问 https://cmake.org/download/ 下载最新版本
2. 安装新版本并重启命令提示符

### 问题2：Visual Studio编译器未找到
**错误信息**: `Could not find CMAKE_CXX_COMPILER`

**解决方案**:
1. 确保已安装"使用C++的桌面开发"工作负载
2. 使用"Developer Command Prompt for VS"而不是普通命令提示符

### 问题3：权限不足
**错误信息**: `Permission denied` 或 `Access denied`

**解决方案**:
1. 以管理员身份运行命令行
2. 确保构建目录有写入权限

### 问题4：路径包含空格
**错误信息**: 各种路径解析错误

**解决方案**:
1. 使用双引号包围包含空格的路径
2. 避免在项目路径中使用空格

### 问题5：旧版Windows SDK
**错误信息**: 链接错误或API未定义

**解决方案**:
1. 确保安装最新版本的Windows SDK
2. 在Visual Studio Installer中更新Windows SDK

## 性能优化

### Release构建
始终使用Release配置进行性能测试：
```cmd
cmake .. -DCMAKE_BUILD_TYPE=Release
cmake --build . --config Release
```

### 编译器优化
对于Visual Studio，使用最大优化：
```cmd
cmake .. -DCMAKE_CXX_FLAGS="/O2 /Ob2 /DNDEBUG" -DCMAKE_BUILD_TYPE=Release
```

### 并行构建
启用多核编译：
```cmd
cmake --build . --parallel
```

## 调试配置

### Debug构建
```cmd
cmake .. -DCMAKE_BUILD_TYPE=Debug
```

### 启用详细输出
```cmd
RegistryLockService.exe -verbose -interval 100 HKEY_CURRENT_USER\Software\MyApp
```

## 交叉编译

### 为不同架构构建

#### x64 (默认)
```cmd
cmake .. -A x64
```

#### x86
```cmd
cmake .. -A Win32
```

#### ARM64
```cmd
cmake .. -A ARM64
```

## CI/CD集成

### GitHub Actions示例
```yaml
name: Build
on: [push, pull_request]
jobs:
  build:
    runs-on: windows-latest
    steps:
    - uses: actions/checkout@v2
    - name: Build with CMake
      run: |
        mkdir build
        cd build
        cmake .. -A x64
        cmake --build . --config Release
```

## 安装和部署

### 创建安装包
使用`cmake --install`：
```cmd
cmake --install . --config Release --prefix C:\RegistryLockService
```

### 复制必要文件
```cmd
mkdir C:\RegistryLockService
copy bin\Release\RegistryLockService.exe C:\RegistryLockService\
copy example_config.txt C:\RegistryLockService\
```

## 验证构建

### 运行自检
```cmd
RegistryLockService.exe -help
```

### 运行测试
```cmd
test_registry.bat
```

### 性能测试
```cmd
performance_test.bat
```

## 故障排除清单

- [ ] CMake版本 >= 3.10
- [ ] Visual Studio工作负载正确安装
- [ ] Windows SDK版本最新
- [ ] 使用正确的命令行工具
- [ ] 权限充足
- [ ] 路径无特殊字符
- [ ] 构建目录干净
- [ ] 使用Release配置进行测试

## 获取帮助

如果遇到构建问题：

1. 检查Visual Studio输出窗口
2. 查看CMake日志
3. 确认系统要求
4. 尝试重新生成CMake缓存
   ```cmd
   rm -rf build
   mkdir build
   cd build
   cmake ..
   ```

5. 检查Windows事件查看器中的相关错误