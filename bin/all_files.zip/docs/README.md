---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 30450220694c8721e2dccd4ee9afb374567470890e396b8acfd75505c5d79d1c32ee9c0902210092a33f942436ae071e3629d5e2193db034dc44b29af3eb8a5a908672e8ade286
    ReservedCode2: 3045022028cd1db7674b5ca85f6f301a75fda457234155e6fbc853b09b3549182d346a4b022100ac3475c9753680424ceb23594bdb0bed1a26e27a73b656d004585683c42c4dba
---

# 注册表动态锁定服务

## 概述

注册表动态锁定服务是一个Windows C++应用程序，用于监控指定的注册表路径并在检测到变更或删除时立即恢复原始值。该服务可以保护重要的注册表设置免受意外或恶意的修改。

## 功能特性

- **实时监控**: 持续监控指定的注册表路径
- **即时恢复**: 检测到变更或删除时立即恢复原始值
- **多路径支持**: 可同时监控多个注册表路径
- **类型保护**: 支持所有Windows注册表数据类型
- **高性能**: 优化的扫描算法，最小化系统资源占用
- **详细日志**: 可选的详细输出模式，便于调试和监控
- **优雅关闭**: 支持Ctrl+C等信号的安全关闭

## 构建要求

- Windows 10/11 或 Windows Server 2016+
- CMake 3.10 或更高版本
- 支持C++17的编译器（MSVC 2019+、MinGW等）
- Visual Studio 2019+ (推荐) 或其他C++开发环境

## 构建步骤

### 方法1：使用Visual Studio (推荐)

1. 打开Visual Studio Installer
2. 安装"使用C++的桌面开发"工作负载
3. 打开Developer Command Prompt for VS
4. 执行以下命令：

```cmd
cd path\to\project
mkdir build
cd build
cmake .. -A x64
cmake --build . --config Release
```

### 方法2：使用CMake + Ninja

1. 安装Ninja构建工具
2. 执行以下命令：

```cmd
cd path\to\project
mkdir build
cd build
cmake .. -G Ninja -DCMAKE_BUILD_TYPE=Release
ninja
```

### 方法3：使用MinGW

```cmd
cd path\to\project
mkdir build
cd build
cmake .. -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release
mingw32-make
```

构建完成后，可执行文件将位于 `build/bin/Release/RegistryLockService.exe`

## 使用方法

### 基本语法

```
RegistryLockService.exe [选项] <注册表路径1> [注册表路径2] ...
```

### 命令行选项

| 选项 | 描述 | 示例 |
|------|------|------|
| `-interval <毫秒>` | 设置扫描间隔 (默认: 100ms) | `-interval 50` |
| `-verbose` | 启用详细输出 | `-verbose` |
| `-help` | 显示帮助信息 | `-help` |

### 支持的根键

| 根键名称 | 简写 | 描述 |
|----------|------|------|
| `HKEY_CLASSES_ROOT` | `HKCR` | 文件关联和COM类信息 |
| `HKEY_CURRENT_USER` | `HKCU` | 当前用户的配置信息 |
| `HKEY_LOCAL_MACHINE` | `HKLM` | 计算机范围的配置信息 |
| `HKEY_USERS` | `HKU` | 所有用户的配置信息 |
| `HKEY_CURRENT_CONFIG` | `HKCC` | 当前硬件配置信息 |

### 使用示例

#### 示例1：监控单个路径

```cmd
RegistryLockService.exe HKEY_CURRENT_USER\Software\MyApp
```

#### 示例2：监控多个路径

```cmd
RegistryLockService.exe HKEY_CURRENT_USER\Software\MyApp HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft
```

#### 示例3：高性能模式

```cmd
RegistryLockService.exe -interval 50 HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft
```

#### 示例4：详细模式

```cmd
RegistryLockService.exe -verbose HKEY_CURRENT_USER\Software\MyApp
```

#### 示例5：完整配置

```cmd
RegistryLockService.exe -interval 75 -verbose HKEY_CURRENT_USER\Software\MyApp HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft
```

## 使用场景

### 1. 保护软件配置

监控应用程序的关键配置项，防止被意外修改：

```cmd
RegistryLockService.exe HKEY_LOCAL_MACHINE\SOFTWARE\MyCompany\MyApp\Settings
```

### 2. 安全防护

保护系统安全相关设置：

```cmd
RegistryLockService.exe HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies
```

### 3. 开发环境

保护开发工具的配置：

```cmd
RegistryLockService.exe HKEY_CURRENT_USER\Software\Microsoft\VisualStudio
```

### 4. 企业环境

批量监控多个关键路径：

```cmd
RegistryLockService.exe HKEY_LOCAL_MACHINE\SOFTWARE\Company A HKEY_LOCAL_MACHINE\SOFTWARE\Company B HKEY_CURRENT_USER\Software\CriticalApp
```

## 工作原理

1. **启动阶段**: 
   - 解析命令行参数
   - 备份指定路径下的所有注册表值
   - 创建监控线程

2. **监控阶段**:
   - 定期扫描备份的注册表值
   - 检测值变更、删除或类型变化
   - 立即恢复检测到的变更

3. **恢复阶段**:
   - 重新创建已删除的值
   - 恢复修改的值到原始状态
   - 保持原始数据类型不变

## 注意事项

### 权限要求

- **HKEY_CURRENT_USER**: 普通用户权限
- **HKEY_LOCAL_MACHINE**: 需要管理员权限
- **HKEY_CLASSES_ROOT**: 通常需要管理员权限

### 性能考虑

- **扫描间隔**: 建议设置为50-200ms，根据系统性能调整
- **监控路径数量**: 过多路径可能影响性能
- **注册表大小**: 大型注册表项可能需要更长的扫描时间

### 安全注意事项

- 确保以适当权限运行程序
- 监控路径选择要谨慎，避免影响系统稳定性
- 定期检查恢复日志，确保服务正常工作
- 生产环境使用前请充分测试

## 故障排除

### 常见问题

1. **权限不足**
   ```
   错误：无法创建键 xxx, 错误码: 5
   ```
   **解决方案**: 以管理员权限运行程序

2. **路径不存在**
   ```
   备份路径失败: HKEY_CURRENT_USER\Software\Nonexistent
   ```
   **解决方案**: 确认注册表路径存在

3. **服务无法启动**
   ```
   服务启动失败
   ```
   **解决方案**: 检查权限和路径参数

### 调试模式

使用 `-verbose` 参数启用详细输出，查看：
- 备份过程详情
- 检测到的变更
- 恢复操作结果
- 错误信息

## 日志说明

程序输出格式：

```
[恢复] HKEY_CURRENT_USER\Software\MyApp\ConfigValue -> 已恢复原始值
[错误] 无法设置值 HKEY_LOCAL_MACHINE\SOFTWARE\test, 错误码: 5
备份: HKEY_CURRENT_USER\Software\MyApp\ValueName (类型: 1)
```

## 性能优化

### 调整扫描间隔

- **高频监控**: 10-50ms (高资源消耗)
- **标准监控**: 50-200ms (推荐)
- **低频监控**: 200ms+ (最小资源消耗)

### 优化建议

1. 根据实际需求调整扫描间隔
2. 避免监控过大的注册表路径
3. 定期重启服务以清理内存
4. 在低峰时段运行大规模监控

## 版本信息

- **当前版本**: 1.0
- **C++标准**: C++17
- **支持平台**: Windows 10/11, Windows Server 2016+

## 许可证

本项目采用MIT许可证。详见LICENSE文件。

## 技术支持

如有问题或建议，请通过以下方式联系：
- 创建Issue
- 发送邮件
- 查看文档

## 更新日志

### v1.0 (当前版本)
- 初始发布
- 基本注册表监控功能
- 多路径支持
- 命令行参数支持
- 详细日志功能