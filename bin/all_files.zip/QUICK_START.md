---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 304402201bab7b750ac3bdadf7618d05268c2b4a5b986b263945e3839499a74dfa07ccf00220255fb6db65b24638ef882cf5de7ac1743e286e0a9845a53522b6e87b8e1cc9c3
    ReservedCode2: 3045022100de8d2e63e619d089077bddd1cee2b32ea665824f52d2a5d27b8ea0c5b3b8b3e5022045c3ceebd74f0cd8ffe9cf77e22969cec10c28c829f726b076425cccdf528054
---

# 快速开始指南

## 🚀 快速启动

### 1. 构建程序

#### 使用Visual Studio (推荐)
```cmd
# 打开Developer Command Prompt for VS
mkdir build
cd build
cmake .. -A x64
cmake --build . --config Release
```

#### 使用CMake + Ninja
```cmd
mkdir build
cd build
cmake .. -G Ninja -DCMAKE_BUILD_TYPE=Release
ninja
```

### 2. 基本使用

#### 监控单个路径
```cmd
RegistryLockService.exe HKEY_CURRENT_USER\Software\MyApp
```

#### 监控多个路径
```cmd
RegistryLockService.exe HKEY_CURRENT_USER\Software\MyApp HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft
```

#### 使用配置文件
```cmd
# 1. 编辑 example_config.txt
# 2. 取消注释需要的路径
RegistryLockService.exe -config example_config.txt
```

#### 高性能模式
```cmd
RegistryLockService.exe -interval 50 -verbose HKEY_CURRENT_USER\Software\MyApp
```

### 3. 测试功能

#### 运行基础测试
```cmd
test_registry.bat
```

#### 性能测试
```cmd
performance_test.bat
```

#### 常用路径监控
```cmd
monitor_common_paths.bat
```

### 4. 安装服务

#### 快速安装
```cmd
install_service.bat
```

## 📋 常用命令

### 基本命令
```cmd
# 显示帮助
RegistryLockService.exe -help

# 监控指定路径
RegistryLockService.exe HKEY_CURRENT_USER\Software

# 使用配置文件
RegistryLockService.exe -config config.txt

# 详细模式
RegistryLockService.exe -verbose HKEY_CURRENT_USER\Software

# 自定义扫描间隔
RegistryLockService.exe -interval 200 HKEY_CURRENT_USER\Software
```

### 组合使用
```cmd
# 高性能详细监控
RegistryLockService.exe -interval 50 -verbose HKEY_CURRENT_USER\Software HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft

# 配置文件 + 详细模式
RegistryLockService.exe -config example_config.txt -verbose
```

## ⚙️ 配置示例

### 简单配置文件 (config.txt)
```
# 注册表锁定服务配置文件
HKEY_CURRENT_USER\Software\MyApp
HKEY_CURRENT_USER\Software\ImportantSettings
# HKEY_LOCAL_MACHINE\SOFTWARE\CompanyApp  # 需要管理员权限
```

### 企业配置文件
```
# 企业环境配置
HKEY_CURRENT_USER\Software
HKEY_LOCAL_MACHINE\SOFTWARE\Policies
HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion
```

## 🧪 测试场景

### 场景1: 测试基本功能
1. 运行 `test_registry.bat`
2. 观察服务启动和监控
3. 在另一个窗口修改注册表
4. 观察自动恢复功能

### 场景2: 性能测试
1. 运行 `performance_test.bat`
2. 选择测试类型
3. 观察CPU和内存使用
4. 测试恢复响应时间

### 场景3: 实际应用
1. 确定要保护的注册表路径
2. 创建配置文件
3. 启动监控服务
4. 验证保护效果

## 🛠️ 故障排除

### 常见问题

#### 权限不足
```
错误：无法创建键 xxx, 错误码: 5
```
**解决方案**: 以管理员权限运行

#### 路径不存在
```
备份路径失败: HKEY_CURRENT_USER\Software\Nonexistent
```
**解决方案**: 确认注册表路径存在

#### 配置文件格式错误
```
配置文件加载失败
```
**解决方案**: 检查配置文件格式，确保路径正确

### 调试模式
```cmd
# 启用详细输出
RegistryLockService.exe -verbose -interval 100 HKEY_CURRENT_USER\Software
```

## 📊 监控输出示例

### 正常启动
```
=== 注册表动态锁定服务 ===
版本: 1.1

添加监控路径: HKEY_CURRENT_USER\Software\MyApp
开始注册表锁定服务...
监控路径数量: 1
备份完成: 1 个路径成功, 0 个路径失败
注册表锁定服务已启动

服务运行中...
按 Ctrl+C 停止服务
```

### 检测到变更
```
[恢复] HKEY_CURRENT_USER\Software\MyApp\ConfigValue -> 已恢复原始值 (大小: 12 字节)
```

### 性能统计
```
监控统计 - 扫描次数: 1000, 恢复次数: 3
```

## 🎯 最佳实践

### 1. 权限管理
- **普通用户路径**: HKEY_CURRENT_USER\* 无需管理员权限
- **系统路径**: HKEY_LOCAL_MACHINE\* 需要管理员权限
- **测试时**: 先用HKEY_CURRENT_USER测试

### 2. 性能优化
- **开发测试**: 使用 100ms 间隔
- **生产环境**: 根据需要调整 50-500ms
- **资源紧张**: 使用 500ms+ 间隔

### 3. 配置管理
- **配置文件**: 便于批量管理
- **版本控制**: 将配置文件加入版本控制
- **备份配置**: 定期备份重要配置

### 4. 监控建议
- **关键路径**: 重点保护核心配置
- **定期检查**: 监控日志确保正常工作
- **性能监控**: 定期检查系统资源使用

## 🔧 自定义开发

### 修改监控路径
编辑 `RegistryLockService.cpp` 中的路径列表

### 调整扫描间隔
使用 `-interval` 参数或修改默认值

### 添加新功能
扩展 `RegistryLockService` 类的成员函数

### 集成到项目
将源码集成到现有C++项目中

## 📞 获取帮助

### 查看详细文档
- `docs/README.md` - 完整使用说明
- `docs/BUILD.md` - 构建指南
- `PROJECT_SUMMARY.md` - 项目总结

### 运行诊断
```cmd
# 检查程序版本
RegistryLockService.exe -help

# 测试基本功能
RegistryLockService.exe -verbose HKEY_CURRENT_USER\Software

# 检查权限
whoami /priv | findstr SeBackupPrivilege
```

---

**快速开始完成！** 🎉

现在您可以开始使用注册表动态锁定服务来保护重要的系统配置了。如有问题，请参考详细文档或运行测试脚本。